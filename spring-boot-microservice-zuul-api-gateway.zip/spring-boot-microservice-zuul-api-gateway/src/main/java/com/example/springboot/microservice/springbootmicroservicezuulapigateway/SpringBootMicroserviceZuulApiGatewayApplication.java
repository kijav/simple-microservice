package com.example.springboot.microservice.springbootmicroservicezuulapigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMicroserviceZuulApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMicroserviceZuulApiGatewayApplication.class, args);
	}
}
